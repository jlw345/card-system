<?php
namespace App; use Illuminate\Database\Eloquent\Model; class ShopTemplate extends Model { const DEFAULT_ID = 0; protected $guarded = array(); public $timestamps = false; }