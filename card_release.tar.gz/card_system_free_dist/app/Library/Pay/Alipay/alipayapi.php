<?php
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>支付宝即时到账交易接口接口</title>
</head>
<?php  require_once 'alipay.config.php'; require_once 'lib/alipay_submit.class.php'; $spe57cf0 = $_POST['WIDout_trade_no']; $spf92b41 = $_POST['WIDsubject']; $spcdaf27 = $_POST['WIDtotal_fee']; $spf1b300 = $_POST['WIDbody']; $sp29b593 = array('service' => $sp387ef9['service'], 'partner' => $sp387ef9['partner'], 'seller_id' => $sp387ef9['seller_id'], 'payment_type' => $sp387ef9['payment_type'], 'notify_url' => $sp387ef9['notify_url'], 'return_url' => $sp387ef9['return_url'], 'anti_phishing_key' => $sp387ef9['anti_phishing_key'], 'exter_invoke_ip' => $sp387ef9['exter_invoke_ip'], 'out_trade_no' => $spe57cf0, 'subject' => $spf92b41, 'total_fee' => $spcdaf27, 'body' => $spf1b300, '_input_charset' => trim(strtolower($sp387ef9['input_charset']))); $spa8ef89 = new AlipaySubmit($sp387ef9); $sp2839ce = $spa8ef89->buildRequestForm($sp29b593, 'get', '确认'); echo $sp2839ce; ?>
</body>
</html><?php 