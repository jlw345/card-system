<?php
if (!defined('AOP_SDK_WORK_DIR')) { define('AOP_SDK_WORK_DIR', '/tmp/'); } if (!defined('AOP_SDK_DEV_MODE')) { define('AOP_SDK_DEV_MODE', true); }