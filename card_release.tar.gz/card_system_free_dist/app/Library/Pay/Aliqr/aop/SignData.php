<?php
class SignData { public $signSourceData = null; public $sign = null; }