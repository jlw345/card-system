<?php
class EncryptResponseData { public $realContent; public $returnContent; }