<?php
class EncryptParseItem { public $startIndex; public $endIndex; public $encryptContent; }