<?php
error_reporting(E_ERROR); require_once 'phpqrcode/phpqrcode.php'; $spc4471f = urldecode($_GET['data']); QRcode::png($spc4471f);