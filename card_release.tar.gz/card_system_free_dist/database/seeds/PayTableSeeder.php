<?php
use Illuminate\Database\Seeder; class PayTableSeeder extends Seeder { private function initPay() { $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '支付宝'; $spb8bfc1->img = '/plugins/images/ali.png'; $spb8bfc1->driver = 'Alipay'; $spb8bfc1->way = 'Alipay'; $spb8bfc1->comment = '支付宝 - 即时到账套餐(企业)V2'; $spb8bfc1->config = '{
  "partner": "partner",
  "key": "key"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_PC; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '支付宝'; $spb8bfc1->img = '/plugins/images/ali.png'; $spb8bfc1->driver = 'Aliwap'; $spb8bfc1->way = 'Aliwap'; $spb8bfc1->comment = '支付宝 - 高级手机网站支付V4'; $spb8bfc1->config = '{
  "partner": "partner",
  "key": "key"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_MOBILE; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '支付宝扫码'; $spb8bfc1->img = '/plugins/images/ali.png'; $spb8bfc1->driver = 'Aliqr'; $spb8bfc1->way = 'Aliqr'; $spb8bfc1->comment = '支付宝 - 当面付'; $spb8bfc1->config = '{
  "app_id": "app_id",
  "alipay_public_key": "alipay_public_key",
  "merchant_private_key": "merchant_private_key"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '微信扫码'; $spb8bfc1->img = '/plugins/images/wx.png'; $spb8bfc1->driver = 'Wechat'; $spb8bfc1->way = 'NATIVE'; $spb8bfc1->comment = '微信支付 - 扫码'; $spb8bfc1->config = '{
  "APPID": "APPID",
  "MCHID": "商户ID",
  "KEY": "KEY",
  "APPSECRET": "APPSECRET"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '微信H5'; $spb8bfc1->img = '/plugins/images/wx.png'; $spb8bfc1->driver = 'Wechat'; $spb8bfc1->way = 'MWEB'; $spb8bfc1->comment = '微信支付 - H5 (需要开通权限)'; $spb8bfc1->config = '{
  "APPID": "APPID",
  "MCHID": "商户ID",
  "KEY": "KEY",
  "APPSECRET": "APPSECRET"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_MOBILE; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '手机QQ'; $spb8bfc1->img = '/plugins/images/qq.png'; $spb8bfc1->driver = 'QPay'; $spb8bfc1->way = 'NATIVE'; $spb8bfc1->comment = '手机QQ - 扫码'; $spb8bfc1->config = '{
  "mch_id": "mch_id",
  "mch_key": "mch_key"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '支付宝'; $spb8bfc1->img = '/plugins/images/ali.png'; $spb8bfc1->driver = 'Youzan'; $spb8bfc1->way = 'alipay'; $spb8bfc1->comment = '有赞支付 - 支付宝'; $spb8bfc1->config = '{
  "client_id": "client_id",
  "client_secret": "client_secret",
  "kdt_id": "kdt_id"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '微信'; $spb8bfc1->img = '/plugins/images/wx.png'; $spb8bfc1->driver = 'Youzan'; $spb8bfc1->way = 'wechat'; $spb8bfc1->comment = '有赞支付 - 微信'; $spb8bfc1->config = '{
  "client_id": "client_id",
  "client_secret": "client_secret",
  "kdt_id": "kdt_id"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '手机QQ'; $spb8bfc1->img = '/plugins/images/qq.png'; $spb8bfc1->driver = 'Youzan'; $spb8bfc1->way = 'qq'; $spb8bfc1->comment = '有赞支付 - 手机QQ'; $spb8bfc1->config = '{
  "client_id": "client_id",
  "client_secret": "client_secret",
  "kdt_id": "kdt_id"
}'; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '支付宝'; $spb8bfc1->img = '/plugins/images/ali.png'; $spb8bfc1->driver = 'CodePay'; $spb8bfc1->way = 'alipay'; $spb8bfc1->comment = '码支付 - 支付宝'; $spb8bfc1->config = '{
  "id": "id",
  "key": "key"
}'; $spb8bfc1->fee_system = 0; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '微信'; $spb8bfc1->img = '/plugins/images/wx.png'; $spb8bfc1->driver = 'CodePay'; $spb8bfc1->way = 'weixin'; $spb8bfc1->comment = '码支付 - 微信'; $spb8bfc1->config = '{
  "id": "id",
  "key": "key"
}'; $spb8bfc1->fee_system = 0; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); $spb8bfc1 = new \App\Pay(); $spb8bfc1->name = '手机QQ'; $spb8bfc1->img = '/plugins/images/qq.png'; $spb8bfc1->driver = 'CodePay'; $spb8bfc1->way = 'qq'; $spb8bfc1->comment = '码支付 - 手机QQ'; $spb8bfc1->config = '{
  "id": "id",
  "key": "key"
}'; $spb8bfc1->fee_system = 0; $spb8bfc1->enabled = \App\Pay::ENABLED_ALL; $spb8bfc1->save(); } public function run() { self::initPay(); } }