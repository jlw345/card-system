<?php
use Illuminate\Database\Seeder; class MyPayTableSeeder extends Seeder { public function run() { } }